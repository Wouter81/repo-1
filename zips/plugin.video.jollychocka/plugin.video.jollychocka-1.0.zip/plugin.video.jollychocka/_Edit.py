import xbmcaddon

MainBase = 'http://www.chockakodi.com/Jolly%20Chocka/crimbo%20txt%20files/jollychocka-home.txt'
addon = xbmcaddon.Addon('plugin.video.jollychocka')