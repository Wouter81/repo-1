service.subtitles.nlondertitels
==========================

NLondertitels.com subtitle service plugin for XBMC 

XBMC Gotham version only. Will not work with Frodo or previous verisons.

Disclaimer: UNOFFICIAL addon! Not responsible for anything that happens - good, bad, or otherwise if you decide to use this addon.

Git clone or download this project into the 'addons' folder.

