import urllib, urllib2, re, cookielib, os, sys, socket
import xbmc, xbmcplugin, xbmcgui, xbmcaddon

import utils, sqlite3


def Main():
    utils.addDir('Live Sport','http://www.foxsports.nl/video/filter/fragments/1/',228,'https://raw.githubusercontent.com/doki1/repo/master/NLView%20XML/fs.png',1,fanart='https://raw.githubusercontent.com/doki1/repo/master/NLView%20XML/fanart.jpg') 
    xbmcplugin.endOfDirectory(utils.addon_handle)

def List(url, page=None):
    listhtml = utils.getHtml2(url)
    match = re.compile(r'<h2>Football News</h2>(.*?)<a href="http://www.nosball.me/news/2046/The_first_contract_for_Dylan_and_De_Smul_with_The_Blues.html">', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for img, name, videopage in match:
        name = utils.cleantext(name)
        videopage = "http://www.foxsports.nl" + videopage
        utils.addDownLink(name, videopage, 231, img, '', fanart='https://raw.githubusercontent.com/doki1/repo/master/NLView%20XML/fanart.jpg')
    if len(match) == 12:
        npage = page + 1        
        url = url.replace('/'+str(page)+'/','/'+str(npage)+'/')
        utils.addDir('Volgende Pagina ('+str(npage)+')', url, 228, '', npage)
    xbmcplugin.endOfDirectory(utils.addon_handle)
    
def SearchList(url, page=None):
    listhtml = utils.getHtml2(url)
    match = re.compile(r'<article class="dcm-article">.*?<a href="(.*?)">.+?src="(.*?)".*?<a href=".*?">(.*?)</a>', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for lijst in match:
        lijst = re.compile(r'<div class="icon">.*?<img src="(.*?)".*?<p class="link"><a href="(.*?)">(.*?)</a></p>', re.DOTALL | re.IGNORECASE).findall(lijst)
        for img, videopage, name in lijst:
            name = utils.cleantext(name)
            utils.addDownLink(name, videopage, 231, img, '', fanart='https://raw.githubusercontent.com/doki1/repo/master/NLView%20XML/fanart.jpg')
    xbmcplugin.endOfDirectory(utils.addon_handle)

def Playvid(url, name):
    listhtml = utils.getHtml2(url)
    videoid = re.compile('data-videoid="(.*?)"', re.DOTALL | re.IGNORECASE).findall(listhtml)[0]
    videoid = 'http://www.foxsports.nl/divadata/Output/VideoData/' + videoid + '.xml'
    videoxml = utils.getHtml2(videoid)
    videourl = re.compile(r'<uri>([^<]+m3u8)</uri>', re.DOTALL | re.IGNORECASE).findall(videoxml)[0]
    if videourl:
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': 'Music'})
        listitem.setProperty("IsPlayable","true")
        if int(sys.argv[1]) == -1:
            pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            pl.clear()
            pl.add(videourl, listitem)
            xbmc.Player().play(pl)
        else:
            listitem.setPath(str(videourl))
            xbmcplugin.setResolvedUrl(utils.addon_handle, True, listitem)

def Search(url):
    searchUrl = url
    vq = utils._get_keyboard(heading="Zoeken naar...")
    if (not vq): return False, 0
    title = urllib.quote_plus(vq)
    title = title.replace(' ','%20')
    searchUrl = searchUrl + title + '&s=date'
    print "Searching URL: " + searchUrl
    SearchList(searchUrl)